"""
RR EngineerWorks Dataset Generator
===================================
Generates RR_EngineerWorks_Dataset.xlsx for the
Power BI Data Analysis for Engineers handbook.

Sheets produced:
  1. Dim_Regions       – CLEAN reference table, 10 rows
  2. Dim_Products      – Category_SubCategory combined column (needs splitting)
  3. Dim_Customers     – Inconsistent city/name casing, ~25 pct blank phones, leading spaces
  4. Fact_Orders       – Mixed date formats, ProductCode casing mess, duplicate rows,
                         null RegionID, some wrong TotalAmount calculations
  5. Fact_Production   – PlannedUnits/ActualUnits stored as text strings in ~30 pct of rows
  6. Targets_Wide      – Month-as-columns (needs unpivoting); region key intentionally
                         uses a slightly different name format than Dim_Regions
  7. HR_Directory      – Completely disconnected: ManagerName is free text, no numeric key
  8. Dim_Date          – Scaffold only (5 sample rows); learners generate full table in DAX
"""

import random, math, os
from datetime import date, timedelta
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

random.seed(42)

OUTPUT = os.path.join(os.path.dirname(__file__), "RR_EngineerWorks_Dataset.xlsx")


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
def make_sheet(wb, name, headers, rows, hdr_hex="1A2332"):
    ws = wb.create_sheet(name)
    hdr_fill = PatternFill("solid", fgColor=hdr_hex)
    hdr_font = Font(bold=True, color="FFFFFF", size=10)
    for c, h in enumerate(headers, 1):
        cell = ws.cell(1, c, h)
        cell.font = hdr_font
        cell.fill = hdr_fill
        cell.alignment = Alignment(horizontal="left", vertical="center")
        ws.column_dimensions[get_column_letter(c)].width = max(len(str(h)) + 6, 14)
    ws.row_dimensions[1].height = 22
    for r, row in enumerate(rows, 2):
        for c, val in enumerate(row, 1):
            ws.cell(r, c, val)
    ws.freeze_panes = "A2"
    return ws


def fmt_date_messy(d):
    """Return the date in one of three formats at random — simulating a messy source."""
    r = random.random()
    if r < 0.34:
        return d.strftime("%d/%m/%Y")      # UK text string – most common mistake
    elif r < 0.67:
        return d.strftime("%Y-%m-%d")      # ISO text string
    else:
        return d                            # actual date object (clean minority)


# ─────────────────────────────────────────────
#  MASTER LOOKUP DATA
# ─────────────────────────────────────────────
REGION_ROWS = [
    ("R01","North England",     "Northern",     "England",   "Sarah Thornton"),
    ("R02","South England",     "Southern",     "England",   "Mark Davies"),
    ("R03","East England",      "Eastern",      "England",   "Priya Sharma"),
    ("R04","West England",      "Western",      "England",   "Tom Hughes"),
    ("R05","Midlands",          "Central",      "England",   "Lisa Patel"),
    ("R06","Scotland",          "Northern",     "Scotland",  "Angus MacLeod"),
    ("R07","Wales",             "Western",      "Wales",     "Rhys Owen"),
    ("R08","Northern Ireland",  "Northern",     "N.Ireland", "Claire Donnelly"),
    ("R09","Europe",            "International","Europe",    "Hendrik Meier"),
    ("R10","Rest of World",     "International","Global",    "Yuki Tanaka"),
]

PRODUCT_ROWS = [
    # (Code, Name, Category_SubCategory combined, UnitCost, ListPrice, Status)
    ("PRD-001","Precision Pressure Sensor",   "Electronics|Sensors",      68.00, 120.00,"Active"),
    ("PRD-002","Temperature Transmitter",     "Electronics|Sensors",      54.50,  95.00,"Active"),
    ("PRD-003","Flow Rate Meter",             "Electronics|Sensors",      92.00, 165.00,"Active"),
    ("PRD-004","PLC Controller Unit",         "Electronics|Controllers", 210.00, 380.00,"Active"),
    ("PRD-005","HMI Touch Display 7in",       "Electronics|Displays",    135.00, 240.00,"Active"),
    ("PRD-006","HMI Touch Display 10in",      "Electronics|Displays",    175.00, 310.00,"Active"),
    ("PRD-007","Industrial Torque Wrench",    "Machinery|Tools",          42.00,  78.00,"Active"),
    ("PRD-008","Calibration Tool Set",        "Machinery|Tools",          88.00, 155.00,"Active"),
    ("PRD-009","Linear Actuator 50mm",        "Machinery|Actuators",     120.00, 215.00,"Active"),
    ("PRD-010","Rotary Actuator 90deg",       "Machinery|Actuators",     145.00, 260.00,"Active"),
    ("PRD-011","AC Induction Motor 1.5kW",    "Machinery|Motors",        195.00, 350.00,"Active"),
    ("PRD-012","DC Servo Motor 2kW",          "Machinery|Motors",        265.00, 470.00,"Active"),
    ("PRD-013","Safety Helmet Class A",       "Safety|PPE",               12.00,  24.00,"Active"),
    ("PRD-014","Cut-Resistant Gloves L",      "Safety|PPE",                8.50,  18.00,"Active"),
    ("PRD-015","Machine Guard Panel 60x60",   "Safety|Guards",            55.00, 100.00,"Active"),
    ("PRD-016","Gas Detector 4-in-1",         "Safety|Detectors",        185.00, 330.00,"Active"),
    ("PRD-017","Smoke Detector Industrial",   "Safety|Detectors",         72.00, 130.00,"Active"),
    ("PRD-018","Conveyor Belt 2m",            "Machinery|Actuators",     320.00, 570.00,"Active"),
    ("PRD-019","Vibration Sensor MEMS",       "Electronics|Sensors",      48.00,  88.00,"Active"),
    ("PRD-020","Power Relay 24V",             "Electronics|Controllers",  15.00,  30.00,"Active"),
    ("PRD-021","Installation Service",        "Services|Installation",     0.00, 250.00,"Active"),
    ("PRD-022","Annual Maintenance Plan",     "Services|Maintenance",      0.00, 180.00,"Active"),
    ("PRD-023","Calibration Service",         "Services|Calibration",      0.00,  95.00,"Active"),
    ("PRD-024","Pneumatic Cylinder 100mm",    "Machinery|Actuators",      78.00, 140.00,"Active"),
    ("PRD-025","Industrial Cable Gland M20",  "Electronics|Connectors",    3.50,   8.00,"Active"),
    ("PRD-026","Encoder Rotary 1024 PPR",     "Electronics|Sensors",      65.00, 118.00,"Active"),
    ("PRD-027","Safety Light Curtain",        "Safety|Guards",            420.00, 750.00,"Active"),
    ("PRD-028","Industrial Switch 8-port",    "Electronics|Controllers",   88.00, 158.00,"Active"),
    ("PRD-029","Hydraulic Pump 12V",          "Machinery|Motors",         210.00, 375.00,"Active"),
    ("PRD-030","Load Cell 200kg",             "Electronics|Sensors",      105.00, 188.00,"Active"),
]

# ProductCode → (UnitCost, ListPrice, RegionID)
PROD_MAP = {r[0]: r for r in PRODUCT_ROWS}

COMPANY_NAMES = [
    "AutoTech Manufacturing","PrecisionParts Ltd","SteelWorks Group","NorthTech Industries",
    "BioFab Systems","AeroComponents UK","Midlands Fabricators","Thames Engineering",
    "Highland Machining","Celtic Manufacturing","Belfast Engineering","EuroMech GmbH",
    "Nordic Parts AB","Iberian Tech SL","Pacific Engineering","Global Parts Inc",
    "Quantum Sensors Ltd","ThermoTech UK","FlowControl Systems","SafetyFirst Ltd",
    "Precision Robotics","Industrial Automation Ltd","PowerSystems UK","AquaTech Solutions",
    "MetalMatrix Corp","TechParts Europe","Sigma Controls","Delta Automation",
    "AlphaWorks Ltd","ZetaEngineering","Meridian Machines","Apex Industrial",
    "CoreTech UK","NovaMech","FusionParts Ltd","Vertex Systems",
    "InfraWorks Group","ProTech Manufacturing","BlueLine Engineering","Summit Components",
    "Ironclad Industries","SkyTech Automation","GreenPower Systems","TerraFab Ltd",
    "RedDot Manufacturing","BlueStar Components","HighGrade Tech","ProMach Solutions",
    "DeltaWave Systems","SteelForce Ltd","CastIron Works","TechVault UK",
    "MechPrecision Ltd","AirFlow Systems","NorTech Industries","WestCoast Machines",
    "IronMould Corp","PeakEngineering","CrestTech Ltd","VortexControl UK",
    "SolidState Systems","MicroDrive Ltd","PulseTech UK","WaveMech Corp",
    "StormTech Engineering","BayTech Ltd","RidgeLine Systems","PinnacleTech",
    "Corecast Engineering","TrueNorth Components","GraniTech Ltd","BoltWorks UK",
    "TitaniumParts Ltd","HorizonMech","ZenithEngineering","AxisControl UK",
    "PrismTech Solutions","AlloyCast Ltd","MassiveMech Group","IntellaCraft UK",
]

CONTACTS = [
    ("James","Whitfield"),("Anita","Desai"),("Robert","Marshall"),("Priya","Kumar"),
    ("Thomas","Fletcher"),("Sarah","Wells"),("Daniel","Okafor"),("Lisa","Chen"),
    ("Marcus","Brown"),("Emma","Watson"),("Ahmed","Hassan"),("Sophie","Taylor"),
    ("Kevin","O'Brien"),("Nina","Schmidt"),("Luke","Morrison"),("Aisha","Patel"),
    ("Craig","Davidson"),("Helen","Roberts"),("Oliver","Stone"),("Fatima","Ali"),
    ("Derek","Lawson"),("Mei","Zhang"),("Paul","Harrison"),("Julia","Martin"),
    ("Sam","Thompson"),("Ingrid","Olsen"),("Carlos","Vega"),("Zara","Sheikh"),
    ("Finn","McLaughlin"),("Diana","Kovacs"),("Chris","Evans"),("Nadia","Petrov"),
    ("Ben","Clarke"),("Yara","Nakamura"),("Connor","Walsh"),("Elena","Russo"),
    ("George","Turner"),("Anya","Williams"),("Hassan","Al-Rashid"),("Kim","Park"),
    ("Ian","Foster"),("Lena","Fischer"),("Moses","Adeyemi"),("Clare","Hughes"),
    ("Viktor","Novak"),("Rachel","Green"),("Tariq","Mohammed"),("Ann","Robertson"),
    ("Jerry","Cooper"),("Mia","Jensen"),("Alex","Wright"),("Bella","Morris"),
    ("Callum","Stewart"),("Diya","Rao"),("Ethan","Fox"),("Freya","Larsen"),
    ("Gio","Romano"),("Hannah","Singh"),("Idris","Eze"),("Jess","Watkins"),
    ("Kai","Yamamoto"),("Laura","Hernandez"),("Max","Burns"),("Nova","Tan"),
    ("Owen","Murphy"),("Petra","Novak"),("Quan","Nguyen"),("Rita","Bakker"),
    ("Seb","Johansson"),("Thea","Lund"),("Uri","Ben-David"),("Val","Kowalski"),
    ("Will","Shaw"),("Xena","Dubois"),("Yoel","Cohen"),("Zoe","Andersen"),
    ("Alec","Gupta"),("Beth","Mcdonald"),("Cole","Patterson"),("Dawn","Nguyen"),
]

CITIES_BY_REGION = {
    "R01": ["Manchester","Leeds","Liverpool","Sheffield","Newcastle","Blackpool","Preston"],
    "R02": ["London","Brighton","Guildford","Maidstone","Reading","Slough","Croydon"],
    "R03": ["Norwich","Cambridge","Ipswich","Peterborough","Colchester","Chelmsford","Luton"],
    "R04": ["Bristol","Plymouth","Bath","Exeter","Truro","Taunton","Gloucester"],
    "R05": ["Birmingham","Coventry","Nottingham","Leicester","Derby","Wolverhampton","Stoke"],
    "R06": ["Edinburgh","Glasgow","Aberdeen","Dundee","Inverness","Perth","Stirling"],
    "R07": ["Cardiff","Swansea","Newport","Bangor","Wrexham","Barry","Bridgend"],
    "R08": ["Belfast","Derry","Lisburn","Newry","Armagh","Antrim","Ballymena"],
    "R09": ["Frankfurt","Amsterdam","Paris","Brussels","Stockholm","Milan","Vienna"],
    "R10": ["Singapore","Chicago","Sydney","Toronto","Dubai","Tokyo","Cape Town"],
}

SALES_REPS = [
    "Sarah Thornton","Mark Davies","Priya Sharma","Tom Hughes","Lisa Patel",
    "Angus MacLeod","Rhys Owen","Claire Donnelly","Hendrik Meier","Yuki Tanaka",
    "James Foster","Anna Reid","Ben Turner","Carla Russo","David Kim",
]

# ─────────────────────────────────────────────
#  SHEET 1 — Dim_Regions  (CLEAN)
# ─────────────────────────────────────────────
def build_dim_regions():
    headers = ["RegionID","RegionName","Territory","Country","RegionalManager"]
    return headers, REGION_ROWS

# ─────────────────────────────────────────────
#  SHEET 2 — Dim_Products  (minor: combined column)
# ─────────────────────────────────────────────
def build_dim_products():
    headers = ["ProductCode","ProductName","Category_SubCategory",
               "UnitCost","ListPrice","Status"]
    # Category_SubCategory is "Electronics|Sensors" etc. — needs splitting in Power Query
    return headers, [r for r in PRODUCT_ROWS]

# ─────────────────────────────────────────────
#  SHEET 3 — Dim_Customers  (MESSY)
# ─────────────────────────────────────────────
def build_dim_customers():
    headers = ["CustomerID","CompanyName","ContactName","City","Country",
               "RegionID","Segment","Phone","Email"]
    rows = []
    for i in range(1, 81):
        cid    = f"C{i:03d}"
        raw_co = COMPANY_NAMES[(i - 1) % len(COMPANY_NAMES)]
        # Deliberate: ~20% get a leading or trailing space
        if random.random() < 0.20:
            company = (" " + raw_co) if random.random() < 0.5 else (raw_co + " ")
        else:
            company = raw_co

        fn, ln     = CONTACTS[(i - 1) % len(CONTACTS)]
        # Deliberate: ~28% ALL CAPS name, ~15% all lowercase
        r = random.random()
        if r < 0.28:
            contact = f"{fn.upper()} {ln.upper()}"
        elif r < 0.43:
            contact = f"{fn.lower()} {ln.lower()}"
        else:
            contact = f"{fn} {ln}"

        region_id = f"R{((i - 1) % 10) + 1:02d}"
        city_pool = CITIES_BY_REGION.get(region_id, ["London"])
        raw_city  = random.choice(city_pool)
        # Deliberate: ~25% UPPERCASE city, ~15% lowercase city
        r2 = random.random()
        if r2 < 0.25:
            city = raw_city.upper()
        elif r2 < 0.40:
            city = raw_city.lower()
        else:
            city = raw_city

        country = ("UK" if region_id not in ("R09","R10")
                   else ("Europe" if region_id == "R09" else "International"))
        segment = random.choice(["Corporate","Corporate","SME","SME","Government"])
        # Deliberate: ~25% blank phone
        phone = ("" if random.random() < 0.25
                 else f"+44-{random.randint(100,999)}-{random.randint(100,999)}-{random.randint(1000,9999)}")
        email = f"{fn.lower()}.{ln.lower().replace(chr(39),'')}@{raw_co.lower().replace(' ','')[:14]}.com"
        rows.append((cid, company, contact, city, country, region_id, segment, phone, email))
    return headers, rows

# ─────────────────────────────────────────────
#  SHEET 4 — Fact_Orders  (VERY MESSY)
# ─────────────────────────────────────────────
def build_fact_orders(customer_rows):
    headers = ["OrderID","OrderDate","CustomerID","ProductCode","Quantity",
               "UnitPrice","DiscountPct","TotalAmount","RegionID","SalesRepName",
               "OrderStatus","SalesChannel"]
    rows     = []
    start_dt = date(2024, 1, 1)

    cust_ids    = [r[0] for r in customer_rows]
    cust_region = {r[0]: r[5] for r in customer_rows}
    prod_codes  = [r[0] for r in PRODUCT_ROWS]

    for i in range(585):
        oid    = f"ORD-{1001 + i:04d}"
        raw_dt = start_dt + timedelta(days=random.randint(0, 364))

        # Deliberate: mixed date formats (1/3 each)
        order_date = fmt_date_messy(raw_dt)

        cid_clean = random.choice(cust_ids)
        # Deliberate: ~15% use "CUST-001" format, ~7% bare integer string
        r_cust = random.random()
        if r_cust < 0.15:
            cust_id = "CUST-" + cid_clean[1:]
        elif r_cust < 0.22:
            cust_id = str(int(cid_clean[1:]))
        else:
            cust_id = cid_clean

        pcode_clean = random.choice(prod_codes)
        # Deliberate: ~15% lowercase, ~8% no dash, ~4% capitalised wrong
        r_prod = random.random()
        if r_prod < 0.15:
            prod_code = pcode_clean.lower()
        elif r_prod < 0.23:
            prod_code = pcode_clean.replace("-","")
        elif r_prod < 0.27:
            prod_code = pcode_clean[0].upper() + pcode_clean[1:].lower()
        else:
            prod_code = pcode_clean

        qty        = random.randint(1, 50)
        list_price = PROD_MAP[pcode_clean][4]
        discount   = random.choice([0.0, 0.0, 0.0, 0.05, 0.10, 0.15])
        correct    = round(qty * list_price * (1 - discount), 2)
        # Deliberate: ~8% wrong TotalAmount
        total = (round(correct * random.uniform(0.78, 1.22), 2)
                 if random.random() < 0.08 else correct)

        region_id = cust_region.get(cid_clean, random.choice([r[0] for r in REGION_ROWS]))
        # Deliberate: ~5% null RegionID
        if random.random() < 0.05:
            region_id = None

        rep = random.choice(SALES_REPS)
        # Deliberate: ~8% leading whitespace on rep name
        if random.random() < 0.08:
            rep = "  " + rep

        status  = random.choice(["Completed","Completed","Completed","Completed",
                                  "Pending","Cancelled","Returned"])
        channel = random.choice(["Direct","Direct","Direct","Online","Partner"])

        rows.append((oid, order_date, cust_id, prod_code, qty, list_price,
                     discount, total, region_id, rep, status, channel))

    # ── Deliberate: insert 15 exact duplicate rows ──
    dup_sources = random.sample(rows[:200], 15)
    for src in dup_sources:
        insert_pos = random.randint(0, len(rows))
        rows.insert(insert_pos, src)

    random.shuffle(rows)  # shuffle so dupes aren't obvious
    return headers, rows

# ─────────────────────────────────────────────
#  SHEET 5 — Fact_Production  (MESSY: text types)
# ─────────────────────────────────────────────
def build_fact_production():
    headers = ["ProductionID","Plant","ProductCode","ProductionMonth",
               "PlannedUnits","ActualUnits","DefectRate_Pct","ShiftCount"]
    rows    = []
    plants  = [
        ("PLT-A","Manchester Plant"),
        ("PLT-B","Birmingham Plant"),
        ("PLT-C","Edinburgh Plant"),
    ]
    # Only physical goods (not services)
    phys_products = [r[0] for r in PRODUCT_ROWS if "Services" not in r[2]]

    pid = 1
    for month_num in range(1, 13):
        month_start = date(2024, month_num, 1)
        for plt_code, plt_name in plants:
            for prod_code in random.sample(phys_products, 8):
                planned = random.randint(80, 600)
                actual  = max(0, int(planned * random.uniform(0.72, 1.18)))
                defect  = round(random.uniform(0.3, 9.5), 2)
                shifts  = random.randint(2, 4)
                prod_id = f"PROD-{pid:04d}"
                pid    += 1

                # Deliberate: ~30% of planned/actual stored as text strings
                if random.random() < 0.30:
                    planned = str(planned)
                    actual  = str(actual)

                rows.append((prod_id, plt_name, prod_code,
                             month_start.strftime("%Y-%m-%d"),
                             planned, actual, defect, shifts))
    return headers, rows

# ─────────────────────────────────────────────
#  SHEET 6 — Targets_Wide  (NEEDS UNPIVOT + wrong join key)
# ─────────────────────────────────────────────
def build_targets_wide():
    months = ["Jan_2024","Feb_2024","Mar_2024","Apr_2024","May_2024","Jun_2024",
              "Jul_2024","Aug_2024","Sep_2024","Oct_2024","Nov_2024","Dec_2024"]
    headers = ["RegionName"] + months

    # Deliberate: slightly different names from Dim_Regions so a join won't work without cleaning
    # Most match, but two are deliberately different
    target_regions = [
        "North England",        # matches R01
        "South England",        # matches R02
        "East England",         # matches R03
        "West England",         # matches R04
        "Midlands",             # matches R05
        "Scotland",             # matches R06
        "Wales",                # matches R07
        "Northern Ireland",     # matches R08
        "Europe - International",  # ← Deliberate: "Europe (International)" in Dim_Regions
        "Rest of World",        # matches R10
    ]

    rows = []
    bases = [95000, 180000, 72000, 88000, 140000, 65000, 48000, 35000, 120000, 55000]
    for region_name, base in zip(target_regions, bases):
        row = [region_name]
        for m in range(12):
            seasonal = 1.0 + 0.25 * math.sin(math.pi * (m - 1) / 6.0)
            tgt = int(base * seasonal * random.uniform(0.92, 1.08))
            row.append(tgt)
        rows.append(tuple(row))
    return headers, rows

# ─────────────────────────────────────────────
#  SHEET 7 — HR_Directory  (DELIBERATELY DISCONNECTED)
# ─────────────────────────────────────────────
def build_hr_directory():
    headers = ["EmployeeID","FullName","Department","JobTitle",
               "HireDate","AnnualSalary_GBP","ManagerName","OfficeLocation"]
    DEPTS = ["Engineering","Sales","Operations","Quality","Finance","HR","IT","Procurement"]
    TITLES = {
        "Engineering":  ["Graduate Engineer","Engineer","Senior Engineer","Lead Engineer","Engineering Manager"],
        "Sales":        ["Sales Executive","Account Manager","Senior Account Manager","Regional Sales Manager","Sales Director"],
        "Operations":   ["Operations Assistant","Operations Analyst","Senior Analyst","Operations Manager","Head of Operations"],
        "Quality":      ["QA Technician","QA Engineer","Senior QA Engineer","Quality Manager","Head of Quality"],
        "Finance":      ["Finance Assistant","Finance Analyst","Senior Finance Analyst","Finance Manager","Head of Finance"],
        "HR":           ["HR Coordinator","HR Advisor","Senior HR Advisor","HR Manager","HR Director"],
        "IT":           ["IT Support Analyst","Systems Analyst","IT Engineer","IT Manager","Head of IT"],
        "Procurement":  ["Buyer","Senior Buyer","Procurement Analyst","Procurement Manager","Head of Procurement"],
    }
    LOCATIONS = ["Manchester","Birmingham","Edinburgh","London","Cardiff","Belfast"]
    FIRST = ["Alice","Bob","Carol","Dave","Emma","Frank","Grace","Harry","Iris","Jack",
             "Kate","Liam","Mona","Neil","Olivia","Peter","Quinn","Rosa","Sam","Tina",
             "Uma","Victor","Wendy","Xavier","Yasmin","Zach","Amy","Brian","Claire",
             "Donald","Emily","Felix","Gina","Harry","Isabelle","Jason","Karen","Larry",
             "Maria","Nick","Oscar","Paula","Roger","Sheila","Terry"]
    LAST  = ["Adams","Baker","Carter","Davis","Evans","Fisher","Green","Harris","Ingram",
             "Jones","King","Lewis","Morris","Nelson","Owen","Price","Quinn","Reed",
             "Smith","Taylor","Underwood","Vance","Wilson","Young","Zhang","Campbell",
             "Robertson","MacDonald","Stewart","Thomson","Anderson","Murray","Scott"]

    rows         = []
    senior_names = []   # used to populate ManagerName as free text

    for i in range(1, 46):
        emp_id   = f"EMP{i:04d}"
        fn       = FIRST[(i - 1) % len(FIRST)]
        ln       = LAST[(i - 1) % len(LAST)]
        full     = f"{fn} {ln}"
        dept     = DEPTS[(i - 1) % len(DEPTS)]
        level    = min(random.randint(0, 4), len(TITLES[dept]) - 1)
        title    = TITLES[dept][level]
        hire     = (date(2015, 1, 1) + timedelta(days=random.randint(0, 3285))).strftime("%d/%m/%Y")
        salary   = random.choice([28000,32000,38000,45000,52000,60000,72000,85000,95000])

        if level >= 3:
            senior_names.append(full)

        # ManagerName is FREE TEXT — no EmployeeID, no RegionID, nothing numeric
        manager = random.choice(senior_names) if senior_names else "John Robertson"
        loc     = random.choice(LOCATIONS)

        rows.append((emp_id, full, dept, title, hire, salary, manager, loc))

    return headers, rows

# ─────────────────────────────────────────────
#  SHEET 8 — Dim_Date  (SCAFFOLD ONLY — 5 sample rows)
# ─────────────────────────────────────────────
def build_dim_date():
    headers = ["DateKey","Date","Year","Quarter","QuarterName",
               "Month","MonthName","Day","DayOfWeek","IsWeekend","FiscalYear"]
    sample_dates = [date(2024, 1, d) for d in [1, 15, 31]] + [date(2024, 6, 1), date(2024, 12, 31)]
    rows = []
    for d in sample_dates:
        is_wknd = 1 if d.weekday() >= 5 else 0
        rows.append((
            int(d.strftime("%Y%m%d")),
            d.strftime("%d/%m/%Y"),
            d.year,
            (d.month - 1) // 3 + 1,
            f"Q{(d.month - 1) // 3 + 1}",
            d.month,
            d.strftime("%B"),
            d.day,
            d.strftime("%A"),
            is_wknd,
            f"FY{d.year}"
        ))
    return headers, rows


# ─────────────────────────────────────────────
#  BUILD WORKBOOK
# ─────────────────────────────────────────────
def main():
    wb = openpyxl.Workbook()
    wb.remove(wb.active)   # discard default blank sheet

    # --- Dim_Regions ---
    h, r = build_dim_regions()
    ws = make_sheet(wb, "Dim_Regions", h, r)
    print(f"  Dim_Regions        : {len(r):>4} rows")

    # --- Dim_Products ---
    h, r = build_dim_products()
    ws = make_sheet(wb, "Dim_Products", h, r)
    print(f"  Dim_Products       : {len(r):>4} rows  (Category_SubCategory combined — split in M3)")

    # --- Dim_Customers ---
    h, cust_rows = build_dim_customers()
    ws = make_sheet(wb, "Dim_Customers", h, cust_rows)
    print(f"  Dim_Customers      : {len(cust_rows):>4} rows  (casing issues, ~25 pct blank phones)")

    # --- Fact_Orders ---
    h, ord_rows = build_fact_orders(cust_rows)
    ws = make_sheet(wb, "Fact_Orders", h, ord_rows)
    print(f"  Fact_Orders        : {len(ord_rows):>4} rows  (mixed dates, code casing, 15 dupes, ~5 pct null RegionID)")

    # --- Fact_Production ---
    h, prod_rows = build_fact_production()
    ws = make_sheet(wb, "Fact_Production", h, prod_rows)
    print(f"  Fact_Production    : {len(prod_rows):>4} rows  (~30 pct PlannedUnits/ActualUnits as text)")

    # --- Targets_Wide ---
    h, tgt_rows = build_targets_wide()
    ws = make_sheet(wb, "Targets_Wide", h, tgt_rows, hdr_hex="7B4F00")
    print(f"  Targets_Wide       : {len(tgt_rows):>4} rows  (wide format needs unpivot; key name mismatch)")

    # --- HR_Directory ---
    h, hr_rows = build_hr_directory()
    ws = make_sheet(wb, "HR_Directory", h, hr_rows, hdr_hex="6D1E1E")
    print(f"  HR_Directory       : {len(hr_rows):>4} rows  (DISCONNECTED — ManagerName free text, no join key)")

    # --- Dim_Date ---
    h, date_rows = build_dim_date()
    ws = make_sheet(wb, "Dim_Date", h, date_rows, hdr_hex="2E4A26")
    ws.cell(1, 1).comment = None
    print(f"  Dim_Date           : {len(date_rows):>4} rows  (scaffold only — generate full table with CALENDARAUTO in M6)")

    # Save
    os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)
    wb.save(OUTPUT)
    print(f"\n✓ Saved → {OUTPUT}")


if __name__ == "__main__":
    print("Generating RR EngineerWorks Dataset...")
    main()
